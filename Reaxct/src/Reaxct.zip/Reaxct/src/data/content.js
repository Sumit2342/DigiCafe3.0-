const products = [
  {
    id: 1,
    name: "Butter Chicken",
    desciption: "4pcs chicken",
    price: 12,
    img: "https://images.unsplash.com/photo-1626508035297-0cd27c397d67?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=2070&q=80",
    quantity: 1,
    totalFoodPrice: 12,
  },
  {
    id: 2,
    name: "Sushi ",
    desciption: "Fresh fish sushi",
    price: 50,
    img: "https://images.unsplash.com/photo-1579871494447-9811cf80d66c?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=2070&q=80",
    quantity: 1,
    totalFoodPrice: 50,
  },
  {
    id: 3,
    name: "Pav Bhaji",
    desciption: "2pcs Pav",
    price: 60,
    img: "https://images.unsplash.com/photo-1606491956689-2ea866880c84?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1921&q=80",
    quantity: 1,
    totalFoodPrice: 60,
  },
  {
    id: 4,
    name: "Fish Curry",
    desciption: "4pcs fish",
    price: 40,
    img: "https://images.unsplash.com/photo-1626508035297-0cd27c397d67?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=2070&q=80",
    quantity: 1,
    totalFoodPrice: 40,
  },
];

export default products;
